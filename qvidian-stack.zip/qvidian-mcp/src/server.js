import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { HttpServerTransport } from "@modelcontextprotocol/sdk/server/transports/http.js";
import { jsonSchema, z } from "zod";
import fetch from "node-fetch";

const SHIM_BASE = process.env.QVIDIAN_SHIM_BASE || "http://qvidian-shim:3010";
const PORT = Number(process.env.PORT || 3020);

const server = new Server(
  { name: "qvidian-bridge", version: "0.1.0", description: "MCP HTTP Streamable bridge that proxies to the Qvidian REST shim" },
  {
    tools: {
      "qvidian.authenticate": {
        description: "Authenticate and discover service URLs",
        inputSchema: jsonSchema(z.object({ baseUrl: z.string().url(), apiKey: z.string().min(1) })),
        handler: async ({ input }) => {
          const r = await fetch(`${SHIM_BASE}/auth`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(input) });
          if (!r.ok) throw new Error(`auth failed: ${r.status} ${await r.text()}`);
          return { content: [{ type: "json", data: await r.json() }] };
        }
      },
      "qvidian.search": {
        description: "Full-text search of Qvidian Library",
        inputSchema: jsonSchema(z.object({ query: z.string().min(1), extra: z.record(z.any()).optional() })),
        handler: async ({ input }) => {
          const r = await fetch(`${SHIM_BASE}/search`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(input) });
          if (!r.ok) throw new Error(`search failed: ${r.status} ${await r.text()}`);
          return { content: [{ type: "json", data: await r.json() }] };
        }
      },
      "qvidian.getContent": {
        description: "Get details for a content item by ID",
        inputSchema: jsonSchema(z.object({ contentId: z.number() })),
        handler: async ({ input }) => {
          const r = await fetch(`${SHIM_BASE}/content/${input.contentId}`);
          if (!r.ok) throw new Error(`getContent failed: ${r.status} ${await r.text()}`);
          return { content: [{ type: "json", data: await r.json() }] };
        }
      },
      "qvidian.savedSearch.list": {
        description: "List saved searches",
        inputSchema: jsonSchema(z.object({}).optional()),
        handler: async () => {
          const r = await fetch(`${SHIM_BASE}/saved-searches`);
          if (!r.ok) throw new Error(`savedSearch.list failed: ${r.status} ${await r.text()}`);
          return { content: [{ type: "json", data: await r.json() }] };
        }
      }
    }
  }
);

const transport = new HttpServerTransport({ port: PORT, cors: { origin: "*", methods: ["GET","POST","OPTIONS"] } });
await server.connect(transport);
console.log(`Qvidian MCP bridge listening on :${PORT}, proxying ${SHIM_BASE}`);
