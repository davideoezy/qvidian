import express from "express";
import morgan from "morgan";
import cors from "cors";
import NodeCache from "node-cache";
import dotenv from "dotenv";
import soap from "soap";
import path from "path";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(morgan("tiny"));

const cache = new NodeCache({ stdTTL: 50 * 60, checkperiod: 120 });

async function callSoapMethod(wsdlUrl, methodName, args) {
  const client = await soap.createClientAsync(wsdlUrl);
  const [result] = await client[`${methodName}Async`](args);
  return result;
}

async function connectByApiKey(baseUrl, apiKey) {
  const authWsdl = `${baseUrl.replace(/\/$/, '')}/webservices/Authentication.asmx?WSDL`;
  const result = await callSoapMethod(authWsdl, "ConnectByAPIKey", { apiKey });
  const r = result?.ConnectByAPIKeyResult || result;
  if (!r?.AuthToken) throw new Error("Authentication failed");
  return { authToken: r.AuthToken, connectionBinding: r };
}

function getCtx() {
  const ctx = cache.get("qvidianAuth");
  if (!ctx) throw new Error("Not authenticated");
  return ctx;
}

app.get("/healthz", (req, res) => res.json({ ok: true }));

app.post("/auth", async (req, res) => {
  try {
    const baseUrl = req.body.baseUrl || process.env.QVIDIAN_BASE_URL;
    const apiKey = req.body.apiKey || process.env.QVIDIAN_API_KEY;
    if (!baseUrl || !apiKey) return res.status(400).json({ error: "Missing baseUrl/apiKey" });
    const { authToken, connectionBinding } = await connectByApiKey(baseUrl, apiKey);
    cache.set("qvidianAuth", { authToken, connectionBinding });
    res.json({ authToken, urls: connectionBinding });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/search", async (req, res) => {
  try {
    const ctx = getCtx();
    const { authToken, connectionBinding } = ctx;
    const q = req.body.query;
    if (!q) return res.status(400).json({ error: "query is required" });
    const libraryWsdl = connectionBinding.LibraryURL.includes("?WSDL") ? connectionBinding.LibraryURL : `${connectionBinding.LibraryURL}?WSDL`;
    const request = { AuthToken: authToken, SearchText: q, ...(req.body.extra || {}) };
    const r = await callSoapMethod(libraryWsdl, "librarySearch", { request });
    res.json(r?.librarySearchResult || r);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/content/:id", async (req, res) => {
  try {
    const ctx = getCtx();
    const { authToken, connectionBinding } = ctx;
    const libraryWsdl = connectionBinding.LibraryURL.includes("?WSDL") ? connectionBinding.LibraryURL : `${connectionBinding.LibraryURL}?WSDL`;
    const request = { AuthToken: authToken, ContentID: Number(req.params.id) };
    const r = await callSoapMethod(libraryWsdl, "libraryContentDetailsGet", { request });
    res.json(r?.libraryContentDetailsGetResult || r);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/saved-searches", async (req, res) => {
  try {
    const ctx = getCtx();
    const { authToken, connectionBinding } = ctx;
    const libraryWsdl = connectionBinding.LibraryURL.includes("?WSDL") ? connectionBinding.LibraryURL : `${connectionBinding.LibraryURL}?WSDL`;
    const request = { AuthToken: authToken };
    const r = await callSoapMethod(libraryWsdl, "librarySavedSearchGetList", { request });
    res.json(r?.librarySavedSearchGetListResult || r);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/mcp.json", (req, res) => {
  res.sendFile(path.resolve("/app/mcp.json"), (err) => {
    if (err) res.status(404).json({ error: "mcp.json not found" });
  });
});

const port = Number(process.env.PORT || 3010);
app.listen(port, () => console.log(`Qvidian REST shim listening on :${port}`));
